export type IconName = 'code' | 'database' | 'trend' | 'megaphone' | 'search' | 'target' | 'users' | 'chart' | 'spark' | 'arrow' | 'play' | 'menu' | 'close' | 'cart' | 'check' | 'edit' | 'trash' | 'plus' | 'minus' | 'mail' | 'clock' | 'send' | 'filter' | 'heart' | 'grid' | 'briefcase' | 'chevron' | 'bolt';

export const services = [
  { icon: 'code' as IconName, title: 'Web Development', text: 'Sitios y plataformas modernas, rápidas y escalables.', color: 'cyan' },
  { icon: 'database' as IconName, title: 'CRM & Data', text: 'Gestiona y potencia tus datos para vender mejor.', color: 'blue' },
  { icon: 'trend' as IconName, title: 'Market Positioning', text: 'Destaca en el mercado con una estrategia accionable.', color: 'violet' },
  { icon: 'megaphone' as IconName, title: 'Performance Marketing', text: 'Convierte más, crece más y mide cada decisión.', color: 'pink' },
];

export const shopCategories = ['Todos', 'Camisetas', 'Caps', 'Accesorios'];
export const shopProducts = [
  { id: 1, name: 'Essential Oversized Tee', category: 'Camisetas', price: 42, tag: 'NUEVO', color: 'graphite', accent: '#292532', image: 'tee' },
  { id: 2, name: 'WST Sunday Service', category: 'Camisetas', price: 48, tag: 'BEST SELLER', color: 'sand', accent: '#c6b7a4', image: 'tee-light' },
  { id: 3, name: 'Sunday Script Cap', category: 'Caps', price: 36, tag: 'LIMITED', color: 'coffee', accent: '#44372e', image: 'cap' },
  { id: 4, name: 'Heavyweight Hoodie', category: 'Camisetas', price: 78, tag: 'DROP 04', color: 'ink', accent: '#17161b', image: 'hoodie' },
  { id: 5, name: 'West Side Tote', category: 'Accesorios', price: 28, tag: 'ESSENTIAL', color: 'cream', accent: '#e8dfd2', image: 'tote' },
  { id: 6, name: 'Archive Logo Tee', category: 'Camisetas', price: 46, tag: 'ARCHIVE', color: 'ash', accent: '#8c8782', image: 'tee-ash' },
];

export const restaurantCategories = ['Todos', 'Pizza', 'Fast Food', 'Noodle', 'Dessert', 'Sea Food', 'Sushi'];
export const restaurantItems = [
  { id: 1, name: 'Onion Pizza', category: 'Pizza', price: 60, rating: 5, emoji: '🍕', description: 'Con onion, cheese, olives y muchas más...' },
  { id: 2, name: 'Mix Veg', category: 'Fast Food', price: 85.1, rating: 5, emoji: '🥗', description: 'Con onion, cheese, olives y muchas más...' },
  { id: 3, name: 'Noodle Soup', category: 'Noodle', price: 50, rating: 5, emoji: '🍜', description: 'Con onion, cheese, olives y muchas más...' },
  { id: 4, name: 'Garden Salad', category: 'Fast Food', price: 15, rating: 5, emoji: '🥬', description: 'Con onion, cheese, olives y muchas más...' },
  { id: 5, name: 'Makai Shorba', category: 'Noodle', price: 65.5, rating: 5, emoji: '🍲', description: 'Con onion, cheese, olives y muchas más...' },
  { id: 6, name: 'Egg Corn', category: 'Sea Food', price: 45, rating: 5, emoji: '🥘', description: 'Con onion, cheese, olives y muchas más...' },
];

export const dashboardChannels = ['Todos', 'Paid Search', 'Email', 'Social', 'Direct'];
export const dashboardRows = [
  { channel: 'Social', sessions: 841, duration: '00:00:34', newSessions: '10.04%', bounce: '54.33%', goals: 104, pages: '5.82' },
  { channel: 'Organic Search', sessions: 813, duration: '00:00:15', newSessions: '10.10%', bounce: '58.08%', goals: 82, pages: '5.72' },
  { channel: 'Paid Search', sessions: 1076, duration: '00:00:42', newSessions: '18.40%', bounce: '48.12%', goals: 161, pages: '6.14' },
  { channel: 'Email', sessions: 982, duration: '00:00:56', newSessions: '8.10%', bounce: '37.50%', goals: 138, pages: '6.38' },
  { channel: 'Direct', sessions: 897, duration: '00:00:26', newSessions: '12.22%', bounce: '61.27%', goals: 96, pages: '4.93' },
];
