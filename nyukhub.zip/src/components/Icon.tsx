import type { IconName } from '../data';

type Props = { name: IconName; size?: number; stroke?: number };

export default function Icon({ name, size = 20, stroke = 1.8 }: Props) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true };
  const paths: Record<string, React.ReactNode> = {
    code: <><path d="m8 9-4 3 4 3"/><path d="m16 9 4 3-4 3"/><path d="m14 5-4 14"/></>,
    database: <><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v7c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 12v7c0 1.7 3.1 3 7 3s7-1.3 7-3v-7"/></>,
    trend: <><path d="M3 17 9 11l4 4 8-9"/><path d="M15 6h6v6"/></>,
    megaphone: <><path d="m3 11 18-5v12L3 14z"/><path d="M11 15v5"/><path d="M6 15v4"/></>,
    search: <><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></>,
    target: <><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="m12 2v3M12 19v3M2 12h3M19 12h3"/></>,
    users: <><path d="M16 21v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V21"/><circle cx="9.5" cy="7" r="3.5"/><path d="M17 11a3.5 3.5 0 0 0 0-7M20.5 21v-1.5a4 4 0 0 0-3-3.8"/></>,
    chart: <><path d="M4 19V5M4 19h16"/><path d="m7 15 3-4 3 2 5-7"/></>,
    spark: <><path d="m12 3 1.3 5.7L19 10l-5.7 1.3L12 17l-1.3-5.7L5 10l5.7-1.3z"/><path d="m19 17 .5 2.5L22 20l-2.5.5L19 23l-.5-2.5L16 20l2.5-.5z"/></>,
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>, play: <path d="m9 6 9 6-9 6z"/>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>, close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    cart: <><path d="M3 4h2l2.1 10.2a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 1.9-1.5L20 8H6"/><circle cx="10" cy="20" r="1"/><circle cx="17" cy="20" r="1"/></>,
    check: <path d="m5 12 4 4L19 6"/>, edit: <><path d="m4 16-.8 4.8L8 20l11.3-11.3-4-4z"/><path d="m13.5 6.5 4 4"/></>, trash: <><path d="M4 7h16M10 11v6M14 11v6"/><path d="m6 7 1 14h10l1-14M9 7V4h6v3"/></>, plus: <><path d="M12 5v14M5 12h14"/></>, minus: <path d="M5 12h14"/>, mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></>, clock: <><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></>, send: <><path d="m21 3-7 18-4-8-8-4z"/><path d="M21 3 10 13"/></>, filter: <path d="M4 5h16l-6 7v6l-4 2v-8z"/>, heart: <path d="M20.8 8.6c0 5.4-8.8 10.3-8.8 10.3S3.2 14 3.2 8.6A4.6 4.6 0 0 1 12 6.3a4.6 4.6 0 0 1 8.8 2.3Z"/>, grid: <><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></>, briefcase: <><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5h8v2M3 12h18M10 12v3h4v-3"/></>, chevron: <path d="m8 10 4 4 4-4"/>, bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7z"/>
  };
  return <svg {...common}>{paths[name]}</svg>;
}
